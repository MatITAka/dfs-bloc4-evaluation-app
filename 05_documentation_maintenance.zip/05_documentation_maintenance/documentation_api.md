# Documentation API — OpsTrack Field Service

## Authentification

Tous les endpoints sous `/api/v1/` requièrent un token API transmis via le header `Authorization: Bearer <token>` ou `X-Api-Token: <token>`.

Les tokens sont gérés dans la table `api_tokens`. Un token doit être actif (`is_active = true`) pour être accepté.

---

## Endpoints

### Health Check

```
GET /api/health
```

Aucune authentification requise. Retourne l'état du service.

**Réponse** :

```json
{
  "status": "ok",
  "service": "OpsTrack",
  "timestamp": "2026-03-16T12:00:00+01:00"
}
```

---

### Tickets

#### Lister les tickets

```
GET /api/v1/tickets
```

**Paramètres query** :

| Paramètre | Type | Description |
|-----------|------|-------------|
| `search` | string | Recherche par titre ou référence |
| `priority` | string | Filtrer par priorité (`low`, `medium`, `high`, `critical`) |
| `per_page` | integer | Nombre de résultats par page (défaut : 15) |
| `page` | integer | Numéro de page |

**Réponse** : collection paginée de `TicketResource`.

#### Créer un ticket

```
POST /api/v1/tickets
Content-Type: application/json
```

**Body** :

| Champ | Type | Requis | Description |
|-------|------|--------|-------------|
| `site_id` | integer | oui | ID du site (doit exister) |
| `opened_by_user_id` | integer | oui | ID de l'utilisateur qui ouvre le ticket |
| `assigned_to_user_id` | integer | non | ID du technicien assigné |
| `title` | string | oui | Titre (max 120 caractères) |
| `description` | string | oui | Description de l'incident |
| `priority` | string | oui | `low`, `medium`, `high`, `critical` |
| `status` | string | non | `new`, `scheduled`, `in_progress`, `resolved`, `closed` (défaut : `new`) |
| `sla_due_at` | date | non | Échéance SLA |

**Réponse** : `TicketResource` (201 Created).

#### Voir un ticket

```
GET /api/v1/tickets/{id}
```

**Réponse** : `TicketResource` avec relations (site, openedBy, assignedTo, interventions).

#### Modifier un ticket

```
PUT /api/v1/tickets/{id}
Content-Type: application/json
```

**Body** : mêmes champs que la création, tous optionnels. Si le statut passe à `resolved` ou `closed`, le champ `closed_at` est automatiquement renseigné.

---

### Techniciens

```
GET /api/v1/technicians
```

**Réponse** : liste des utilisateurs avec le rôle `technician`.

---

### Météo (contexte externe)

```
GET /api/v1/external/weather?site_id={id}
```

Retourne les conditions météo actuelles pour le site spécifié, via l'API Open-Meteo.

**Réponse** :

```json
{
  "data": {
    "provider": "open-meteo",
    "site": "Lyon Confluence Lyon",
    "city": "Lyon",
    "current": {
      "temperature_2m": 14.2,
      "weather_code": 3,
      "wind_speed_10m": 8.5
    },
    "fetched_at": "2026-03-16T12:00:00+01:00"
  }
}
```

---

### Webhook

```
POST /hooks.php
Authorization: Basic <base64(user:password)>
Content-Type: application/json
```

**Body** :

| Champ | Type | Requis | Description |
|-------|------|--------|-------------|
| `ticket_reference` | string | oui | Référence du ticket (ex: `INC-240301`) |
| `status` | string | oui | Nouveau statut du ticket |
| `summary` | string | non | Résumé de l'événement |
| `external_event_id` | string | non | ID de l'événement dans le système source |

**Réponse** :

```json
{
  "message": "Webhook processed.",
  "intervention_id": 3
}
```
