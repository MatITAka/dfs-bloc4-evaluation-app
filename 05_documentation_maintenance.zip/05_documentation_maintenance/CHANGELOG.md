# Changelog — OpsTrack Field Service

Toutes les modifications notables de ce projet sont documentées dans ce fichier.

## [1.0.1] — 2026-03-16

### Corrections de bugs

- **Webhook — statut du ticket ignoré** : le webhook (`hooks.php`) forçait systématiquement le statut du ticket à `scheduled`, quel que soit le statut transmis dans le payload. Le ticket reflète désormais le statut réellement envoyé par le système externe.
  - Fichier modifié : `app/Http/Controllers/WebhookController.php`

- **Dashboard — KPIs non actualisés** : les compteurs du tableau de bord (tickets ouverts, critiques, créés aujourd'hui) étaient mis en cache pour 30 minutes sans invalidation. Ajout d'un observer sur le modèle `Ticket` qui invalide le cache `dashboard.kpis` à chaque sauvegarde ou suppression.
  - Fichiers modifiés : `app/Models/Ticket.php`

### Corrections de sécurité

- **Injection SQL dans la recherche de tickets** : le paramètre `search` de l'endpoint `GET /api/v1/tickets` était injecté directement dans une clause `orWhereRaw` sans échappement. Remplacement par un binding paramétré via le query builder Laravel (`orWhere`).
  - Fichier modifié : `app/Http/Controllers/Api/TicketController.php`
  - Sévérité : **critique**
  - Voir `SECURITY.md` pour les détails.

### Infrastructure

- Mise en production sur EC2 Ubuntu 24.04 (eu-west-3)
- HTTPS Let's Encrypt avec TLS 1.3
- Structure de déploiement releases/symlinks mise en place
- Microservice Next.js dispatch-dashboard déployé sur `/dispatch`

## [1.0.0] — 2026-03-14

### Ajout initial

- Application OpsTrack Field Service — Laravel 12 / PHP 8.4
- API REST (tickets, techniciens, météo)
- Webhook pour événements externes
- Microservice Next.js dispatch-dashboard
- Journalisation MongoDB via EventLogService
