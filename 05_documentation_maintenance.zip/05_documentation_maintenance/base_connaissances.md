# Note de passation — OpsTrack Field Service

Ce document est destiné à un développeur reprenant la maintenance de l'application.

---

## 1. Présentation de l'application

OpsTrack Field Service est une application de gestion d'interventions terrain (field service management). Elle permet de suivre les tickets d'incidents, planifier les interventions des techniciens et superviser l'activité via un tableau de bord.

### Stack technique

| Composant | Technologie | Version |
|-----------|------------|---------|
| Backend / API | Laravel | 12.54.1 |
| Langage | PHP | 8.4.18 |
| BDD relationnelle | MySQL | 8.0.45 |
| BDD documentaire | MongoDB | 8.0.19 |
| Cache | Redis | 7.0.15 (disponible, non activé par défaut) |
| Microservice | Next.js | 15.3.1 |
| Runtime Node | Node.js | 18.19.1 |
| Serveur web | Apache2 | 2.4.58 |
| OS | Ubuntu | 24.04.4 LTS |

### Architecture des composants

```
Utilisateurs → Apache2 (TLS) → Laravel (PHP-FPM) → MySQL
                     │                    ├──→ MongoDB (logs)
                     │                    ├──→ Redis (disponible)
                     │                    └──→ Open-Meteo API (météo)
                     └──→ /dispatch → Next.js (port 3000) → API Laravel
                     
Webhook externe → hooks.php → WebhookController → MySQL + MongoDB
```

---

## 2. Accès et credentials

### Serveur de production

| Élément | Valeur |
|---------|--------|
| IP | `51.45.7.228` |
| SSH | `ssh -i ubuntu.pem ubuntu@51.45.7.228` |
| URL | `https://eval-dfs-p-tpl-20261-05.it-students.fr` |
| Dispatch | `https://eval-dfs-p-tpl-20261-05.it-students.fr/dispatch` |

### Credentials (épreuve)

| Service | Utilisateur | Mot de passe |
|---------|------------|-------------|
| MySQL root | `root` | `0000` |
| MySQL applicatif | `user1` | `0000` |
| MongoDB | (sans auth) | — |
| API Token | — | `change-me` |
| Webhook | `user` | `password` |

**En production réelle, tous ces credentials doivent être remplacés par des valeurs fortes.**

---

## 3. Structure du projet

### Arborescence des dossiers clés

```
/var/www/opstrack/
├── current → releases/XXXXXXXX/     ← symlink actif (suivi par Apache)
├── releases/                         ← historique des déploiements
├── shared/
│   ├── .env                          ← config production (partagée)
│   └── storage/                      ← logs, cache, sessions (partagé)
└── (fichiers originaux du clone git)
```

### Code source

```
app/
├── Http/
│   ├── Controllers/
│   │   ├── DashboardController.php        ← tableau de bord (vue Blade)
│   │   ├── WebhookController.php          ← réception événements externes
│   │   └── Api/
│   │       ├── TicketController.php       ← CRUD tickets (API REST)
│   │       ├── TechnicianController.php   ← liste techniciens
│   │       └── ExternalContextController.php  ← météo Open-Meteo
│   ├── Middleware/
│   │   └── EnsureApiTokenIsValid.php      ← auth API par Bearer token
│   └── Requests/
│       ├── StoreTicketRequest.php         ← validation création ticket
│       └── UpdateTicketRequest.php        ← validation modification ticket
├── Models/
│   ├── Ticket.php                         ← modèle principal
│   ├── Customer.php, Site.php, User.php, Intervention.php
│   ├── ApiToken.php                       ← tokens d'accès API
│   └── Mongo/
│       └── EventLog.php                   ← modèle MongoDB (journalisation)
└── Services/
    ├── EventLogService.php                ← écriture logs dans MongoDB
    └── PublicWeatherService.php           ← client API Open-Meteo
```

---

## 4. Points d'attention

### Ordre des migrations

Les fichiers de migration ont tous le même timestamp (`2026_03_14_183114`). L'ordre alphabétique par défaut provoque des erreurs de foreign key. Les fichiers ont été renommés pour forcer l'ordre : `customers → sites → tickets → interventions → api_tokens`.

**Si vous recréez la base depuis le repo non patché, pensez à renommer les migrations.**

### Extension MongoDB

L'extension `ext-mongodb` installée est en version 2.1.4. Le `composer.lock` exige 2.2+. Le `composer install` nécessite le flag `--ignore-platform-req=ext-mongodb`. L'application fonctionne normalement malgré cette différence de version mineure.

### Sessions, queues et cache

Par défaut, les trois utilisent le driver `database` (MySQL), pas Redis. Redis est installé et configuré mais non activé. Pour basculer, modifier les variables `SESSION_DRIVER`, `QUEUE_CONNECTION` et `CACHE_STORE` dans `.env`.

### Microservice Next.js

Le dispatch-dashboard consomme l'API Laravel via le token `OPSTRACK_API_TOKEN`. Si le token change dans le `.env` Laravel, il faut aussi le mettre à jour dans le service systemd (`/etc/systemd/system/dispatch-dashboard.service`) puis `systemctl daemon-reload && systemctl restart dispatch-dashboard`.

---

## 5. Procédures opérationnelles

### Déploiement

Le déploiement est documenté dans `03_deploiement_ci_cd.md`. En résumé : GitHub Actions avec `workflow_dispatch`, quality gate PHPUnit, rsync vers une nouvelle release, bascule du symlink `current`, reload PHP-FPM.

**Rollback** :

```bash
ls -lt /var/www/opstrack/releases/
ln -sfn /var/www/opstrack/releases/<RELEASE_PRECEDENTE> /var/www/opstrack/current
sudo systemctl reload php8.4-fpm
```

### Sauvegarde

Backup quotidien à 2h via cron (`/usr/local/bin/opstrack-backup.sh`). Dumps MySQL et MongoDB dans `/var/backups/opstrack/`, rotation à 7 jours.

### Monitoring

Script de monitoring toutes les 5 minutes via cron (`/usr/local/bin/opstrack-monitor.sh`). Vérifie : health check Laravel, MySQL, Redis, espace disque. Logs dans `/var/log/opstrack-monitor.log`.

### Commandes utiles

```bash
# Vider le cache Laravel
php artisan cache:clear && php artisan config:cache && php artisan route:cache

# Relancer les migrations
php artisan migrate --force

# Voir les logs applicatifs
tail -f /var/www/opstrack/shared/storage/logs/laravel.log

# Voir les logs MongoDB
mongosh opstrack_logs --eval "db.app_events.find().sort({recorded_at:-1}).limit(10).pretty()"

# Statut des services
systemctl status apache2 php8.4-fpm mysql mongod redis-server dispatch-dashboard

# Espace disque
df -h /
```

---

## 6. Bugs connus corrigés

Voir `CHANGELOG.md` et `SECURITY.md` pour le détail.

| Problème | Fichier | Statut |
|----------|--------|--------|
| Webhook force le statut `scheduled` | `WebhookController.php` | Corrigé v1.0.1 |
| KPIs dashboard en cache non invalidé | `Ticket.php` + `DashboardController.php` | Corrigé v1.0.1 |
| SQL injection dans la recherche | `TicketController.php` | Corrigé v1.0.1 |
