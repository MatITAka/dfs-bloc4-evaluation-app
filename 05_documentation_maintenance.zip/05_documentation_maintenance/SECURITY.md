# Journal de sécurité — OpsTrack Field Service

## Failles identifiées et corrigées

### [VULN-001] Injection SQL via le paramètre de recherche de tickets

- **Date de découverte** : 16 mars 2026
- **Sévérité** : Critique
- **Statut** : Corrigé
- **Endpoint concerné** : `GET /api/v1/tickets?search=`
- **Fichier** : `app/Http/Controllers/Api/TicketController.php`, ligne 26

**Description** :

Le paramètre `search` de l'endpoint de recherche de tickets était injecté directement dans une clause SQL brute via `orWhereRaw()`, sans aucun échappement ni binding paramétré :

```php
// Code vulnérable
->orWhereRaw("reference like '%{$search}%'");
```

Un attaquant authentifié (possédant un token API valide) pouvait exploiter cette faille pour exécuter du SQL arbitraire sur la base de données MySQL, permettant potentiellement l'extraction de données sensibles (utilisateurs, tickets, interventions), la modification ou la suppression de données, et l'énumération de la structure de la base.

**Exemple d'exploitation** :

```
GET /api/v1/tickets?search=' OR 1=1 --
GET /api/v1/tickets?search=' UNION SELECT token,is_active,3,4,5,6,7,8,9,10,11,12 FROM api_tokens --
```

**Correctif appliqué** :

```php
// Code corrigé — binding paramétré
->orWhere('reference', 'like', '%' . $search . '%');
```

Le query builder Laravel échappe automatiquement les valeurs. L'injection SQL n'est plus possible.

**Facteurs atténuants** :

- L'endpoint est protégé par le middleware `api.token` — seuls les détenteurs d'un token API valide peuvent effectuer des requêtes.
- Cependant, une compromission de token (ou un token faible comme `change-me`) rendrait la faille immédiatement exploitable.

---

## Mesures de sécurité en place

| Mesure | Détail |
|--------|--------|
| HTTPS | TLS 1.3 via Let's Encrypt, redirection HTTP→HTTPS |
| Fichiers sensibles | `.env` bloqué par Apache (403), permissions 640 |
| Services non exposés | MySQL, MongoDB, Redis sur `127.0.0.1` uniquement |
| Pare-feu | UFW : seuls ports 22, 80, 443 ouverts |
| Authentification API | Token Bearer via middleware `EnsureApiTokenIsValid` |
| Authentification webhook | HTTP Basic Auth |
| Mode production | `APP_DEBUG=false`, `APP_ENV=production`, `LOG_LEVEL=error` |
| Sessions | Cookie `secure` + `httponly` + `samesite=lax` |

## Recommandations pour la suite

1. **Remplacer les mots de passe par défaut** : `DB_PASSWORD=0000`, `OPSTRACK_API_TOKEN=change-me`, `WEBHOOK_BASIC_PASSWORD=password` doivent être remplacés par des valeurs fortes en contexte réel.
2. **Mettre en place un rate limiting** sur les endpoints API pour prévenir le brute force.
3. **Auditer régulièrement les tokens API** : désactiver les tokens inutilisés (`last_used_at` ancien).
4. **Mettre à jour l'extension ext-mongodb** vers la version 2.2+ lorsqu'elle sera disponible dans le PPA.
