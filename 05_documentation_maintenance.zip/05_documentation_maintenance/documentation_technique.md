# Documentation technique — OpsTrack Field Service

Documentation générée depuis l'analyse du code source le 2026-03-16.

---

## Modèles (app/Models/)

### App\Models\Customer
**Fichier** : `app/Models/Customer.php`  
Entité client. Un client possède un ou plusieurs sites d'intervention.

### App\Models\Site
**Fichier** : `app/Models/Site.php`  
Site physique d'intervention. Lié à un client (`customer_id`). Possède des coordonnées GPS (`latitude`, `longitude`) utilisées par le service météo.  
**Relations** : `belongsTo(Customer)`, `hasMany(Ticket)`

### App\Models\User
**Fichier** : `app/Models/User.php`  
Utilisateur de l'application. Le champ `role` distingue les techniciens des autres utilisateurs.

### App\Models\Ticket
**Fichier** : `app/Models/Ticket.php`  
Modèle principal — ticket d'incident ou de maintenance.  
**Champs fillable** : `site_id`, `opened_by_user_id`, `assigned_to_user_id`, `reference`, `title`, `description`, `priority`, `status`, `sla_due_at`, `closed_at`, `last_synced_weather_at`  
**Statuts** : `new`, `scheduled`, `in_progress`, `resolved`, `closed`  
**Priorités** : `low`, `medium`, `high`, `critical`  
**Relations** : `belongsTo(Site)`, `belongsTo(User, opened_by_user_id)`, `belongsTo(User, assigned_to_user_id)`, `hasMany(Intervention)`  
**Observer** : `booted()` invalide le cache `dashboard.kpis` à chaque sauvegarde ou suppression.

### App\Models\Intervention
**Fichier** : `app/Models/Intervention.php`  
Intervention planifiée ou réalisée. Créée automatiquement lors de la réception d'un webhook.  
**Relations** : `belongsTo(Ticket)`

### App\Models\ApiToken
**Fichier** : `app/Models/ApiToken.php`  
Token d'authentification API. `last_used_at` mis à jour par le middleware à chaque requête.

### App\Models\Mongo\EventLog
**Fichier** : `app/Models/Mongo/EventLog.php`  
Modèle MongoDB (connexion `mongodb`, collection `app_events`).  
**Champs** : `channel`, `event_type`, `severity`, `payload` (array), `recorded_at` (datetime)

---

## Contrôleurs (app/Http/Controllers/)

### DashboardController
**Fichier** : `app/Http/Controllers/DashboardController.php`  
Contrôleur invocable pour le tableau de bord. Affiche les 8 derniers tickets et des KPIs en cache.

### WebhookController
**Fichier** : `app/Http/Controllers/WebhookController.php`  
**Méthode** : `handle(Request)` — reçoit les événements externes via HTTP Basic Auth, crée une intervention, met à jour le ticket, journalise dans MongoDB.

### Api\TicketController
**Fichier** : `app/Http/Controllers/Api/TicketController.php`  
**Méthodes** : `index` (liste paginée + recherche), `store` (création avec ref `INC-XXXXXX`), `show` (détail), `update` (modification + détection clôture). Toutes les actions journalisées dans MongoDB.

### Api\TechnicianController
**Fichier** : `app/Http/Controllers/Api/TechnicianController.php`  
**Méthode** : `index()` — liste des techniciens.

### Api\ExternalContextController
**Fichier** : `app/Http/Controllers/Api/ExternalContextController.php`  
**Méthode** : `weather(Request)` — météo actuelle via Open-Meteo pour un site donné.

---

## Services (app/Services/)

### EventLogService
**Fichier** : `app/Services/EventLogService.php`  
**Méthode** : `record(channel, eventType, payload, severity)` — écriture dans MongoDB avec fallback sur le log Laravel si indisponible.

### PublicWeatherService
**Fichier** : `app/Services/PublicWeatherService.php`  
**Méthode** : `currentForSite(Site)` — appel API Open-Meteo (timeout 8s).

---

## Middleware

### EnsureApiTokenIsValid
**Fichier** : `app/Http/Middleware/EnsureApiTokenIsValid.php`  
Vérifie le token API (header `Authorization: Bearer` ou `X-Api-Token`). Met à jour `last_used_at`.

---

## Routes

### Web
| Méthode | URI | Contrôleur |
|---------|-----|-----------|
| GET | `/` | `DashboardController` |

### API (middleware `api.token`)
| Méthode | URI | Contrôleur |
|---------|-----|-----------|
| GET | `/api/health` | closure (sans auth) |
| GET | `/api/v1/tickets` | `TicketController@index` |
| POST | `/api/v1/tickets` | `TicketController@store` |
| GET | `/api/v1/tickets/{id}` | `TicketController@show` |
| PUT | `/api/v1/tickets/{id}` | `TicketController@update` |
| GET | `/api/v1/technicians` | `TechnicianController@index` |
| GET | `/api/v1/external/weather` | `ExternalContextController@weather` |

### Webhook
| Méthode | URI | Authentification |
|---------|-----|-----------------|
| POST | `/hooks.php` | HTTP Basic Auth |
